package io.github.devsamuelj.kanary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KanaryApplicationTests {

	@Test
	void contextLoads() {
	}

}
