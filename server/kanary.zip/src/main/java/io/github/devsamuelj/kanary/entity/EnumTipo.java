package io.github.devsamuelj.kanary.entity;

public enum EnumTipo {
    LIDER,
    COLABORADOR
}
