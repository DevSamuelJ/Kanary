package io.github.devsamuelj.kanary;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KanaryApplication {

	public static void main(String[] args) {
		SpringApplication.run(KanaryApplication.class, args);
	}

}
